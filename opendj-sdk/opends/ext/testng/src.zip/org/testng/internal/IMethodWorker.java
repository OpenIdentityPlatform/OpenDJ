package org.testng.internal;


/**
 * This class/interface 
 */
public interface IMethodWorker extends Runnable {
  long getMaxTimeOut();
}
