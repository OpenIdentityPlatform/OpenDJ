package org.testng.internal.annotations;

import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Configuration;
import org.testng.annotations.DataProvider;
import org.testng.annotations.ExpectedExceptions;
import org.testng.annotations.Factory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

/**
 * This class implements IAnnotationFinder with JDK5 annotations
 * 
 * Created on Dec 20, 2005
 * @author <a href="mailto:cedric@beust.com">Cedric Beust</a>
 */public class JDK15AnnotationFinder implements IAnnotationFinder {
  private JDK15TagFactory m_tagFactory = new JDK15TagFactory();
  private Map<Class<?>, Class<?>> m_annotationMap = 
    new HashMap<Class<?>, Class<?>>();
  
  public JDK15AnnotationFinder() {
    m_annotationMap.put(IConfiguration.class, Configuration.class);
    m_annotationMap.put(IDataProvider.class, DataProvider.class);
    m_annotationMap.put(IExpectedExceptions.class, ExpectedExceptions.class);
    m_annotationMap.put(IFactory.class, Factory.class);
    m_annotationMap.put(IParameters.class, Parameters.class);
    m_annotationMap.put(ITest.class, Test.class);
  }

  public IAnnotation findAnnotation(Class cls, Class annotationClass) {
    Class a = m_annotationMap.get(annotationClass);
    return findAnnotation(cls, cls.getAnnotation(a), annotationClass);
  }

  public IAnnotation findAnnotation(Method m, Class annotationClass) {
    Class a = m_annotationMap.get(annotationClass);
    return findAnnotation(m.getDeclaringClass(), m.getAnnotation(a), annotationClass);
  }
  
  public IAnnotation findAnnotation(Constructor m, Class annotationClass) {
    Class a = m_annotationMap.get(annotationClass);
    return findAnnotation(m.getDeclaringClass(), m.getAnnotation(a), annotationClass);
  }

  public IAnnotation findAnnotation(Class cls, Annotation a, Class annotationClass) {
    return m_tagFactory.createTag(cls, a, annotationClass);
  }

  public void addSourceDirs(String[] dirs) {
    // no-op for JDK 15
  }

  
}
