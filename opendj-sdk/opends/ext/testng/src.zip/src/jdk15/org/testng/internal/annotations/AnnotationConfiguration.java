package org.testng.internal.annotations;

import org.testng.internal.annotations.IAnnotationFinder;

/**
 * This class is responsible for returning the correct IAnnotationFinder.
 * 
 * Created on Dec 20, 2005
 * @author <a href="mailto:cedric@beust.com">Cedric Beust</a>
 */
public class AnnotationConfiguration {
  public static final int JVM_15_CONFIG = 1;
  public static final int JVM_14_CONFIG = 2;
  
  private IAnnotationFinder m_jdk14Finder = new JDK14AnnotationFinder();
  private IAnnotationFinder m_jdk15Finder = new JDK15AnnotationFinder();
  
  private static AnnotationConfiguration m_instance = new AnnotationConfiguration();

  public static AnnotationConfiguration getInstance() {
    return m_instance;
  }

  private int m_annotationType= JVM_14_CONFIG;
  
  public Class[] getAllAnnotations() {
    return new Class[] {
        IConfiguration.class, IDataProvider.class, IExpectedExceptions.class,
        IFactory.class, IParameters.class, ITest.class
    };
  }
  
  public IAnnotationFinder getAnnotationFinder() {
    return m_annotationType == JVM_15_CONFIG ?
        m_jdk15Finder : m_jdk14Finder;
  }
  
  public IAnnotationFinder getJavadocAnnotationFinder() {
    return m_jdk14Finder;
  }  

  public void initialize(int annotationType) {
    m_annotationType = annotationType;
  }
}
