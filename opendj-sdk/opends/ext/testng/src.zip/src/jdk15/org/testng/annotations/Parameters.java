package org.testng.annotations;

import java.lang.annotation.Target;
import java.lang.annotation.Retention;
import static java.lang.annotation.RetentionPolicy.RUNTIME;
import static java.lang.annotation.ElementType.*;

/**
 * Describes how to pass parameters to a @Test method.
 * 
 * @author <a href="mailto:cedric@beust.com">Cedric Beust</a>
 */

@Retention(RUNTIME)
@Target({METHOD, CONSTRUCTOR, TYPE })
public @interface Parameters {
  /**
   * The list of variables used to fill the parameters of this method.
   * These variables must be defined in your testng.xml file.
   * For example
   * <p>
   * <code>
   * &#064;Parameters({ "xmlPath" })<br>
   * &#064;Test<br>
   * public void verifyXmlFile(String path) { ... }<br>
   * </code>
   * <p>and in <tt>testng.xml</tt>:<p>
   * <code>
   * &lt;parameter name="xmlPath" value="account.xml" /&gt;<br>
   * </code>
   */
  public String[] value() default {};
  
  /**
   * The values we will be using to invoke this test.  As opposed to value,
   * no testng.xml is required in this case since the values are hardcoded
   * directly in the annotation.
   */
//  public Object[] values() default {};

}
