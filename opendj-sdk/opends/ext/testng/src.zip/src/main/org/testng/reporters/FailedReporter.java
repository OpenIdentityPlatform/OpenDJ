package org.testng.reporters;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.ITestContext;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;
import org.testng.internal.MethodHelper;
import org.testng.internal.Utils;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

/**
 * This reporter is responsible for creating testng-failed.xml
 * 
 * @author <a href="mailto:cedric@beust.com">Cedric Beust</a>
 */
public class FailedReporter extends TestListenerAdapter {
  public static final String TESTNG_FAILED_XML = "testng-failed.xml";
  
  private XmlSuite m_xmlSuite;
  
  public FailedReporter(XmlSuite xmlSuite) {
    m_xmlSuite = xmlSuite;
  }

  @Override
  public void onFinish(ITestContext context) {
    // Delete the previous file
    File f = new File(context.getOutputDirectory(), getFileName(context));
    f.delete();
    
    // Calculate the methods we need to rerun :  failed tests and
    // their dependents
    List<ITestResult> failedTests = getFailedTests();
    List<ITestResult> skippedTests = getSkippedTests();
    // Note:  we can have skipped tests and no failed tests
    // if a method depends on nonexistent groups
    if (skippedTests.size() > 0 || failedTests.size() > 0) {
      Map<ITestNGMethod, ITestNGMethod> methodsToReRun = 
        new HashMap<ITestNGMethod, ITestNGMethod>();
      
      // Get the transitive closure of all the failed methods and the methods
      // they depend on
      List<ITestResult> tests = failedTests.size() > 0 ? failedTests : skippedTests;
      for (ITestResult failedTest : tests) {
        ITestNGMethod current = failedTest.getMethod();
        if (current.isTest()) {
          methodsToReRun.put(current, current);
          ITestNGMethod method = failedTest.getMethod();
          // Don't count configuration methods
          if (method.isTest()) {
            List<ITestNGMethod> methodsDependedUpon = 
              MethodHelper.getMethodsDependedUpon(method, context.getAllTestMethods());
            
            for (ITestNGMethod m : methodsDependedUpon) {
              if (m.isTest()) {
                methodsToReRun.put(m, m);
              }
            }
          }
        }
      }
      
      //
      // Now we have all the right methods.  Go through the list of
      // all the methods that were run and only pick those that are
      // in the methodToReRun map.  Since the methods are already
      // sorted, we don't need to sort them again.
      //
      List<ITestNGMethod> result = new ArrayList<ITestNGMethod>();
      for (ITestNGMethod m : context.getAllTestMethods()) {
        if (null != methodsToReRun.get(m)) {
          result.add(m);
        }
      }
      
      generateFile(context, result);
    }    // failedTests.size() > 0
  }
  
  /**
   * Generate testng-failed.xml
   */
  private void generateFile(ITestContext context, List<ITestNGMethod> methods) {
    XmlSuite xmlSuite = (XmlSuite) m_xmlSuite.clone();
    xmlSuite.setName("Failed suite");
    XmlTest xmlTest = new XmlTest(xmlSuite);
    xmlTest.setName("Failed tests");
    List<XmlClass> xmlClasses = createXmlClasses(methods);
    xmlTest.setXmlClasses(xmlClasses);
    
//    ppp(xmlSuite.toXml());
    String fileName = TESTNG_FAILED_XML;
    
    Utils.writeFile(context.getOutputDirectory(), fileName, xmlSuite.toXml());
//    Utils.log(context.getOutputDirectory(), 1, "Creating " + fileName);
  }
  
  /**
   * @param methods The methods we want to represent
   * @return A list of XmlClass objects (each representing a <class> tag) based
   * on the parameter methods
   */
  private List<XmlClass> createXmlClasses(List<ITestNGMethod> methods) {
    List<XmlClass> result = new ArrayList<XmlClass>();
    Map<String, List<String>> map = new HashMap<String, List<String>>();
    
    for (ITestNGMethod m : methods) {
      String className = m.getRealClass().getName();
      String method = m.getMethod().getName();
      List<String> methodList = map.get(className);
      if (null == methodList) {
        methodList = new ArrayList<String>();
        map.put(className, methodList);
      }
      methodList.add(method);
    }
    
    for (String className : map.keySet()) {
      List<String> includedMethods = map.get(className);
      XmlClass xmlClass = new XmlClass(className);
      xmlClass.setIncludedMethods(includedMethods);
      result.add(xmlClass);
    }
    
    return result;
  }

  /**
   * TODO:  we might want to make that more flexible in the future, but for
   * now, hardcode the file name
   */
  private String getFileName(ITestContext context) {
    return TESTNG_FAILED_XML;
  }
  
  private static void ppp(String s) {
    System.out.println("[FailedReporter] " + s);
  }
}
