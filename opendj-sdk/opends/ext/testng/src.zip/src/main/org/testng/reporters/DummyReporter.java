package org.testng.reporters;

import java.util.List;

import org.testng.IReporter;
import org.testng.ISuite;
import org.testng.xml.XmlSuite;

public class DummyReporter implements IReporter {

  public void generateReport(List<XmlSuite> xmlSuites, List<ISuite> suites, String outputDir) {
    ppp("GENERATING REPORT FOR " + suites.size() + " SUITES IN " + outputDir);
  }

  private void ppp(String string) {
    System.out.println("[DummyReporter] " + string);
  }

}
