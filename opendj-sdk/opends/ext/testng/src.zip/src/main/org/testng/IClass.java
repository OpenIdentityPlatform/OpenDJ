package org.testng;

import java.io.Serializable;

/**
 * This class represents the class of a test and also contains
 * its instances.
 * 
 * @author <a href="mailto:cedric@beust.com">Cedric Beust</a>
 */
public interface IClass extends Serializable {
  
  /**
   * @return The name of this test class
   */
  public String getName();

  public Class getRealClass();
  
  public Object[] getInstances(boolean create);
  public int getInstanceCount();
  public long[] getInstanceHashCodes();
  
  public void addInstance(Object instance);


}
