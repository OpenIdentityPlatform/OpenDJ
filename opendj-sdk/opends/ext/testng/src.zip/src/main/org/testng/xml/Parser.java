package org.testng.xml;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

public class Parser {
  public static final String TESTNG_DTD = "testng-1.0.dtd"; 
  public static final String DEPRECATED_TESTNG_DTD_URL = "http://beust.com/testng/" + TESTNG_DTD;
  public static final String TESTNG_DTD_URL= "http://testng.org/" + TESTNG_DTD;
  public static final String DEFAULT_FILENAME = "testng.xml";
  
  private String m_fileName = null;
  private InputStream m_inputStream = null;

  /**
   * look in Jar for the file instead?
   */
  private boolean m_lookInJar = false;
  
  /**
   * create a parser that works on a given file
   */
  public Parser(String fileName) 
    throws ParserConfigurationException, SAXException, IOException 
  {
    m_fileName = fileName;
    m_inputStream = new FileInputStream(new File(m_fileName));
  }
  
  public Parser(InputStream inputStream) {
    m_inputStream = inputStream;
  }
  
  /**
   * create a parser that will try to find the DEFAULT_FILENAME from the jar
   */
  public Parser()
    throws ParserConfigurationException, SAXException, IOException 
  {
  }
  
  public XmlSuite parse() throws IOException, ParserConfigurationException, SAXException {
    XmlSuite result = null;
    
    TestNGContentHandler ch = new TestNGContentHandler();
    SAXParserFactory spf = null;
    try {
      spf = SAXParserFactory.newInstance();
    }
    catch(FactoryConfigurationError ex) {
      // If running with JDK 1.4
      try {
        Class cl = Class.forName("org.apache.crimson.jaxp.SAXParserFactoryImpl");
        spf = (SAXParserFactory) cl.newInstance();
      }
      catch(Exception ex2) {
        ex2.printStackTrace();
      }
    }
    spf.setValidating(true);
    SAXParser saxParser = spf.newSAXParser();
    if (m_inputStream != null) {
      saxParser.parse(m_inputStream, ch);     
    } 
    else {
      // try to look for the DEFAULT_FILENAME from the jar
      ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
      InputStream in;
      if (classLoader != null) {
        in = classLoader.getResourceAsStream(DEFAULT_FILENAME);
      }
      else {
        in = getClass().getResourceAsStream(DEFAULT_FILENAME);

      }
      if (in == null) {
        throw new IOException("Default property file of " + DEFAULT_FILENAME
            + " was not found");
      }
      saxParser.parse(in, ch);
    }

    result = ch.getSuite();
    return result;
  }
  
  private static void ppp(String s) {
    System.out.println("[Parser] " + s);
  }
  
  public static void main(String[] argv) 
    throws FileNotFoundException, ParserConfigurationException, SAXException, IOException 
  {
    XmlSuite l = 
      new Parser("c:/eclipse-workspace/testng/test/testng.xml").parse();
    
    System.out.println(l);
  }
}

