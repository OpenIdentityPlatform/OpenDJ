package org.testng.reporters;


/**
 * Constants for HTML generation
 *
 * @author Cedric Beust, May 12, 2004
 * 
 */
public class HTMLConstants {

  public static final String RED = "#DD0000";
  public static final String LIGHT_GREEN = "#006600";
  public static final String GREEN = "#00AA00";
  public static final String YELLOW = "#CCCC00";

}
