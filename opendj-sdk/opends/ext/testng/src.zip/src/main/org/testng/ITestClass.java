package org.testng;

import java.io.Serializable;

/**
 * This class represents a test class:
 * <ul>
 * <li> The test methods
 * <li>The configuration methods (test and method)
 * <li>The class file
 * </ul>
 * 
 * Note that the methods returned by instances of this class
 * are expected to be correct at runtime.  In other words,
 * they might differ from what the ITestMethodFinder returned
 * since ITestClass will take into account the groups being
 * included and excluded.
 * 
 * @author <a href="mailto:cedric@beust.com">Cedric Beust</a>
 */
public interface ITestClass extends IClass, Serializable {
  
  /**
   * @return All the instances the methods will be invoked upon.
   * This will typically be an array of one object in the absence
   * of an @Factory annotation.
   */
  Object[] getInstances(boolean reuse);
  long[] getInstanceHashCodes();

  /**
   * @return The number of instances used in this class.  This method
   * is needed for serialization since we don't know ahead of time if the
   * instances of the test classes will be serializable.
   */
  int getInstanceCount();
  
  /**
   * @return All the applicable test methods.
   */
  ITestNGMethod[] getTestMethods();
  
  /**
   * @return All the methods that should be invoked
   * before a test method is invoked.
   */
  ITestNGMethod[] getBeforeTestMethods();

  /**
   * @return All the methods that should be invoked
   * after a test method completes.
   */
  ITestNGMethod[] getAfterTestMethods();
  
  /**
   * @return All the methods that should be invoked
   * after the test class has been created and before
   * any of its test methods is invoked.
   */
  ITestNGMethod[] getBeforeClassMethods();

  /**
   * @return All the methods that should be invoked
   * after all the tests have been run on this class.
   */
  ITestNGMethod[] getAfterClassMethods();

  /**
   * @return All the methods that should be invoked
   * before the suite is run.
   */
  ITestNGMethod[] getBeforeSuiteMethods();

  /**
   * @return All the methods that should be invoked
   * after the suite has run.
   */
  ITestNGMethod[] getAfterSuiteMethods();

  /**
   * @return all @Configuration methods that should be invoked before any others in the current test
   */
  ITestNGMethod[] getBeforeTestConfigurationMethods();
  
  /**
   * @return all @Configuration methods that should be invoked last before any others
   * in the current test
   */
  ITestNGMethod[] getAfterTestConfigurationMethods();
  
  /**
   * @return all @Configuration methods that should be invoked before certain groups
   */
  ITestNGMethod[] getBeforeGroupsMethods();

  /**
   * @return all @Configuration methods that should be invoked after certain groups
   */
  ITestNGMethod[] getAfterGroupsMethods();

}
