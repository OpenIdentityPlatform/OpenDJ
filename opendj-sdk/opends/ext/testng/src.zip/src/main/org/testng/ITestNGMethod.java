package org.testng;


import java.io.Serializable;
import java.lang.reflect.Method;

/**
 * Describes a test method and the instance on which it will be invoked
 *
 * @author Cedric Beust, May 3, 2004
 *
 */
public interface ITestNGMethod extends Comparable, Serializable {

  /**
   * @return The real class on which this method was declared
   * (can be different from getMethod().getDeclaringClass() if
   * the test method was defined in a superclass).
   */
  Class getRealClass();

  ITestClass getTestClass();

  void setTestClass(ITestClass cls);

  /**
   * @return The test method.
   */
  Method getMethod();
  
  /**
   * Needed for serialization since methods are not Serializable
   */
  String getMethodName();

  /**
   * @return All the instances the methods will be invoked upon.
   * This will typically be an array of one object in the absence
   * of an @Factory annotation.
   */
  Object[] getInstances();

  /**
   * Needed for serialization.
   */
  long[] getInstanceHashCodes();

  /**
   * @return The groups this method belongs to, possibly added to the groups
   * declared on the class.
   */
  String[] getGroups();

  /**
   * @return The groups this method depends on, possibly added to the groups
   * declared on the class.
   */
  String[] getGroupsDependedUpon();

  /**
   * If a group was not found.
   */
  String getMissingGroup();
  public void setMissingGroup(String group);
  
  /**
   * Before and After groups
   */
  public String[] getBeforeGroups();
  public String[] getAfterGroups();

  /**
   * @return The methods  this method depends on, possibly added to the methods
   * declared on the class.
   */
  String[] getMethodsDependedUpon();
  void addMethodDependedUpon(String methodName);

  /**
   * @return true if this method was annotated with @Test
   */
  boolean isTest();

  /**
   * @return true if this methow was annotated with @Configuration
   * and beforeTestMethod = true
   */
  boolean isBeforeMethodConfiguration();

  /**
   * @return true if this methow was annotated with @Configuration
   * and beforeTestMethod = false
   */
  boolean isAfterMethodConfiguration();

  /**
   * @return true if this methow was annotated with @Configuration
   * and beforeClassMethod = true
   */
  boolean isBeforeClassConfiguration();

  /**
   * @return true if this methow was annotated with @Configuration
   * and beforeClassMethod = false
   */
  boolean isAfterClassConfiguration();

  /**
   * @return true if this methow was annotated with @Configuration
   * and beforeSuite = true
   */
  boolean isBeforeSuiteConfiguration();

  /**
   * @return true if this methow was annotated with @Configuration
   * and afterSuite = true
   */
  boolean isAfterSuiteConfiguration();

  boolean isBeforeTestConfiguration();

  boolean isAfterTestConfiguration();

  /**
   * @return The timeout in milliseconds.
   */
  long getTimeOut();

  /**
   * @return the number of times this method needs to be invoked.
   */
  int getInvocationCount();

  /**
   * @return the success percentage for this method (between 0 and 100).
   */
  int getSuccessPercentage();

  /**
   * @return The id of the thread this method was run in.
   */
  long getId();

  void setId(long id);

  long getDate();

  void setDate(long date);

  /**
   * Returns if this ITestNGMethod can be invoked from within IClass.
   */
  boolean canRunFromClass(IClass testClass);
  
  /**
   * @return true if this method is alwaysRun=true
   */
  boolean isAlwaysRun();

  int getThreadPoolSize();

  public String getDescription();

  public boolean isBeforeGroupsConfiguration();

  public boolean isAfterGroupsConfiguration();

}
