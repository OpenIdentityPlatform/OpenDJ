package org.testng.xml;

import java.util.Arrays;


/**
 * This class represents an XML <suite> that contains several classes
 *
 * given a class name CLS
 * it is equivalent to the xml of
     <suite name="$CLS">
       <test name="$CLS">
      <classes>
             <class name="$CLS"/>
             <class name="..."
       </classes>
      </test>
     </suite>
      
 * 
 * @author jolly
 */
public class ClassSuite extends XmlSuite {

  public ClassSuite (String testName, XmlClass[] classes) {
    super();
    XmlTest oneTest = new XmlTest(this);
    oneTest.setName(testName);
    oneTest.setXmlClasses(Arrays.asList(classes));
    setName("Suite for " + testName);  // set the suite name to the class name, too
  }

}
