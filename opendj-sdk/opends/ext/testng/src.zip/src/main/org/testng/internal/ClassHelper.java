package org.testng.internal;


import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.testng.IMethodSelector;
import org.testng.TestNGException;
import org.testng.internal.annotations.IAnnotation;
import org.testng.internal.annotations.IAnnotationFinder;
import org.testng.internal.annotations.IFactory;

/**
 * Utility class for different class manipulations.
 *
 * @author <a href="mailto:the_mindstorm@evolva.ro">Alex Popescu</a>
 */
public class ClassHelper {

  /**
   * Loads the specified class from the context ClassLoader or if none,
   * than from the default ClassLoader.
   *
   * @return the class or null if the loading has failed
   */
  public static Class forName(final String className) {
    ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
    Class clazz= null;
    try {
      if(classLoader != null) {

        // Thread has custom classloader
        try {
          clazz= classLoader.loadClass(className);
        }
        catch(Exception ex) {
          clazz= Class.forName(className);
        }
      }
      else {

        // Use default classloader
        clazz= Class.forName(className);
      }
    }
    catch(ClassNotFoundException cnfe) {
      ; // nothing to be done
    }

    return clazz;
  }

  /**
   * The method annotated with @Factory or null if none is found.
   *
   * @return  the @Factory <CODE>Method</CODE> or null
   *
   * FIXME: @Factory method must be public!
   */
  public static Method findFactoryMethod(Class cls, IAnnotationFinder finder) {
    Method result= null;

    for(Method method : cls.getDeclaredMethods()) {
      IAnnotation f= finder.findAnnotation(method, IFactory.class);

      if(null != f) {
        if(null != result) {
          throw new TestNGException(cls.getName() + ":  only one @Factory method allowed");
        }
        else {
          result= method;
        }
      }
    }

    // If we didn't find anything, look for nested classes
//    if (null == result) {
//      Class[] subClasses = cls.getClasses();
//      for (Class subClass : subClasses) {
//        result = findFactoryMethod(subClass, finder);
//        if (null != result) {
//          break;
//        }
//      }
//    }

    // Found the method, verify that it returns an array of objects
    // TBD

    return result;
  }

  private static void ppp(String s) {
    System.out.println("[ClassHelper] " + s);
  }

  /**
   * Extract all callable methods of a class and all its super (keeping in mind
   * the Java access rules).
   *
   * @param clazz
   * @return
   */
  public static Set<Method> getAvailableMethods(Class clazz) {
    Set<Method> methods= new HashSet<Method>(Arrays.asList(clazz.getDeclaredMethods()));

    String fqn= clazz.getName();

    Class parent= clazz.getSuperclass();

    while(null != parent) {
      methods.addAll(extractMethods(clazz, parent, methods));
      parent= parent.getSuperclass();
    }

    return methods;
  }

  private static Set<Method> extractMethods(final Class childClass, final Class clazz, final Set<Method> collected) {
    Set<Method> methods= new HashSet<Method>();

    Method[] declaredMethods= clazz.getDeclaredMethods();

    Package childPackage= childClass.getPackage();
    Package classPackage= clazz.getPackage();
    boolean isSamePackage= false;

    if((null == childPackage) && (null == classPackage)) {
      isSamePackage= true;
    }
    if((null != childPackage) && (null != classPackage)) {
      isSamePackage= childPackage.getName().equals(classPackage.getName());
    }

    for(Method method : declaredMethods) {
      int methodModifiers= method.getModifiers();
      if(Modifier.isPublic(methodModifiers)
        || Modifier.isProtected(methodModifiers)) {
        if(!isOverridden(method, collected)) {
          methods.add(method);
        }
      }
      else if(isSamePackage && !Modifier.isPrivate(methodModifiers)) {
        if(!isOverridden(method, collected)) {
          methods.add(method);
        }
      }
    }

    return methods;
  }

  private static boolean isOverridden(Method method, Set<Method> collectedMethods) {
    Class methodClass= method.getDeclaringClass();
    Class[] methodParams= method.getParameterTypes();
    
    for(Method m: collectedMethods) {
      Class[] paramTypes= m.getParameterTypes();
      if(method.getName().equals(m.getName())
         && methodClass.isAssignableFrom(m.getDeclaringClass())
         && methodParams.length == paramTypes.length) {
        
        boolean sameParameters= true;
        for(int i= 0; i < methodParams.length; i++) {
          if(!methodParams[i].equals(paramTypes[i])) {
            sameParameters= false;
            break;
          }
        }
        
        if(sameParameters) {
          return true;
        }
      }
    }
    
    return false;
  }
  
  public static IMethodSelector createSelector(org.testng.xml.XmlMethodSelector selector) {
    try {
      Class cls = Class.forName(selector.getClassName());
      return (IMethodSelector) cls.newInstance();
    }
    catch(Exception ex) {
      throw new TestNGException("Couldn't find method selector : " + selector.getClassName(), ex);
    }
  }
}
