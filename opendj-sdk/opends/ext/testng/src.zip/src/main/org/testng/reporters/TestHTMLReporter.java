package org.testng.reporters;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.testng.ITestContext;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.TestListenerAdapter;
import org.testng.internal.Utils;


/**
 * This class implements an HTML reporter for individual tests.
 *
 * @author Cedric Beust, May 2, 2004
 * 
 */
public class TestHTMLReporter extends TestListenerAdapter {
  private ITestContext m_testContext = null;
  private File m_htmlOutputFile = null;
  
  /////
  // implements ITestListener
  //
  
  @Override
  public void onStart(ITestContext context) {
    m_testContext = context;
  }

  @Override
  public void onFinish(ITestContext context) {
    generateLog(m_testContext, null /* host */,
        m_testContext.getOutputDirectory(), 
        getPassedTests(), getFailedTests(),
        getSkippedTests(), getFailedButWithinSuccessPercentageTests());
  }
  
  //
  // implements ITestListener
  /////

  private static File getOutputFile(String outputDirectory, ITestContext context) {
    String result = outputDirectory + File.separator + context.getName() + ".html";
//    File result = new File(base);
//    String path = result.getAbsolutePath();
//    int index = path.lastIndexOf(".");
//    base = "file://" + path.substring(0, index) + ".out";
    
    return new File(result);
  }
  
  public static void generateTable(StringBuffer sb, String title, 
      Collection<ITestResult> tests, String bgColor)
  {
    sb
    .append("<table width=\"100%\"border=\"1\" bgcolor=\"" + bgColor + "\">\n")
    .append("<tr><td colspan=\"3\" align=\"center\"><b>").append(title).append("</b></td></tr>\n")    
    .append("<tr>")
    .append("<td><b>Test method</b></td>\n")
    .append("<td width=\"10%\"><b>Time (seconds)</b></td>\n")
    .append("<td width=\"30%\"><b>Exception</b></td>\n")
    .append("</tr>\n");
    
    Comparator testResultComparator = new Comparator<ITestResult>() {
      public int compare(ITestResult o1, ITestResult o2) {
        String c1 = o1.getName();
        String c2 = o2.getName();
        return c1.compareTo(c2);
      }

      @Override
      public boolean equals(Object obj) {
        return super.equals(obj);
      }
    };
    
    if (tests instanceof List) {
      Collections.sort((List) tests, testResultComparator);
    }

    int i = 0;
    
    for (ITestResult tr : tests) {
      sb.append("<tr>\n");

      // Test method
      ITestNGMethod method = tr.getMethod();

      String fqName = method.toString();
      sb.append("<td>").append(fqName);
      
      // Method description
      if (! Utils.isStringEmpty(method.getDescription())) {
        sb.append("<br><b>").append(method.getDescription()).append("</b><br>");
      }
      
      // Output, if any
      Object[] parameters = tr.getParameters();
      if (parameters != null) {
        sb.append("<br><b>Parameters:</b> ");
        for (int j = 0; j < parameters.length; j++) {
          if (j > 0) sb.append(", ");
          sb.append(parameters[j].toString());
        }
        sb.append("<br>");

      // User output?
        {
          List<String> output = Reporter.getOutput(tr);
          if (null != output && output.size() > 0) {
            
            // Method name
            String divId = "Output-" + tr.hashCode();
            sb.append("\n<a href=\"#" + divId + "\" onClick=\"toggleBox('" + divId
                + "');\">Show output</a>\n")
                .append("\n<a href=\"#" + divId + "\" onClick=\"toggleAllBoxes();\">Show all outputs</a>\n")
                ;
            
            // Method output
            sb.append("<div class=\"log\" id=\"" + divId + "\">\n");
            for (String s : output) {
              sb.append(s).append("<br>\n");
            }
            sb.append("</div>\n");
          }
        }
      }
      
      sb.append("</td>\n");
      
      // Time
      long time = (tr.getEndMillis() - tr.getStartMillis()) / 1000;
      String strTime = new Long(time).toString();
      sb.append("<td>").append(strTime).append("</td>\n");
      
      // Exception
      Throwable tw = tr.getThrowable();
      String stackTrace = "";
      String t = "none";
      if (null != tw) {
//        t = "<a href=\"" + m_outOutputFileName + "\">" + tw.toString() + "</a>";
        t = "";
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        PrintWriter writer = new PrintWriter(baos);
        writer.write("<p><pre>");
       
        //
        // Patch by Justin Lee to see the < and > in HTML
        //
        StringWriter string = new StringWriter();
        PrintWriter printer = new PrintWriter(string);
        tw.printStackTrace(printer);
        String result = string.getBuffer().toString().replaceAll("<", "&lt;")
            .replaceAll(">", "&gt;");
        writer.write(result);

        writer.write("</pre></p>");
        writer.flush();
        writer.close();

        stackTrace = baos.toString();
      }
      sb.append("<td>").append(t).append(stackTrace).append("</td>\n");
      
      sb.append("</tr>\n");
    }
    
    sb.append("</table><p>\n");
  }
  
  private static String arrayToString(String[] array) {
    StringBuffer result = new StringBuffer();
    for (int i = 0; i < array.length; i++) {
      result.append(array[i]).append(" ");
    }
    
    return result.toString();
  }
  
  private static String HEAD =
    "\n<style type=\"text/css\">\n" +
    ".log { visibility:hidden;} \n" +
    "</style>\n" +
    "<script type=\"text/javascript\">\n" +
      "<!--\n" +
      "function flip(e) {\n" +
      "  current = e.style.visibility;\n" +
      "  if (current == 'visible') {\n" +
      "    e.style.visibility = 'hidden';\n" +
      "  }\n" +
      "  else {\n" +
      "    e.style.visibility = 'visible';\n" +
      "  }\n" +
      "}\n" +
      "\n" +
      "function toggleBox(szDivId)\n" +
      "{\n" +
      "  if (document.getElementById) {\n" +
      "    flip(document.getElementById(szDivId));\n" +
      "  }\n" +
      "  else if (document.all) {\n" +
      "    // this is the way old msie versions work\n" +
      "    var style2 = document.all[szDivId].style;\n" +
      "    style2.display = style2.display? \"\":\"block\";\n" +
      "  }\n" +
      "\n" +
      "}\n" +
      "\n" +
      "function toggleAllBoxes() {\n" +
      "  if (document.getElementsByTagName) {\n" +
      "    d = document.getElementsByTagName('div');\n" +
      "    for (i = 0; i < d.length; i++) {\n" +
      "      if (d[i].className == 'log') {\n" +
      "        flip(d[i]);\n" +
      "      }\n" +
      "    }\n" +
      "  }\n" +
      "}\n" +
      "\n" +
      "// -->\n" +
      "</script>\n" +
      "\n";
  
  public static void generateLog(ITestContext testContext, 
      String host, String outputDirectory,
      Collection<ITestResult> passedTests, Collection<ITestResult> failedTests,
      Collection<ITestResult> skippedTests, Collection<ITestResult> percentageTests)
  {
    File htmlOutputFile = getOutputFile(outputDirectory, testContext);
	  StringBuffer sb = new StringBuffer();
	  sb.append("<html>\n<head>\n")
      .append("<title>TestNG:  ").append(testContext.getName()).append("</title>")
      .append(HEAD)
	    .append("</head>\n")
	    .append("<body>\n");
	  
	  Date startDate = testContext.getStartDate();
	  Date endDate = testContext.getEndDate();
	  long duration = (endDate.getTime() - startDate.getTime()) / 1000;
    int passed = 
      Utils.calculateInvokedMethodCount(testContext.getPassedTests()) +
      Utils.calculateInvokedMethodCount(testContext.getFailedButWithinSuccessPercentageTests());
    int failed = Utils.calculateInvokedMethodCount(testContext.getFailedTests());
    int skipped = Utils.calculateInvokedMethodCount(testContext.getSkippedTests());
    String hostLine = Utils.isStringEmpty(host) ? "" : "<tr><td>Remote host:</td><td>" + host
        + "</td>\n</tr><tr>";
	  
	  sb
	  .append("<h2><p align=\"center\">").append(testContext.getName()).append("</p></h2>")
    .append("<table align=\"center\">\n")
    .append("<tr>\n")
//    .append("<td>Property file:</td><td>").append(m_testRunner.getPropertyFileName()).append("</td>\n")
//    .append("</tr><tr>\n")
    .append("<td>Tests passed/Failed/Skipped:</td><td>").append(passed).append("/").append(failed).append("/").append(skipped).append("</td>\n")
    .append("</tr><tr>\n")
	  .append("<td>Started on:</td><td>").append(testContext.getStartDate().toString()).append("</td>\n")
    .append("</tr>\n")
    .append(hostLine)
	  .append("<td>Total time:</td><td>").append(duration).append(" seconds</td>\n")
    .append("</tr><tr>\n")
	  .append("<td>Included groups:</td><td>").append(arrayToString(testContext.getIncludedGroups())).append("</td>\n")
    .append("</tr><tr>\n")
	  .append("<td>Excluded groups:</td><td>").append(arrayToString(testContext.getExcludedGroups())).append("</td>\n")
    .append("</tr>\n")
    .append("</table><p>\n")
	  ;
	  
    if (failedTests.size() > 0) {
      generateTable(sb, "FAILED TESTS", failedTests, HTMLConstants.RED);
    }
    if (percentageTests.size() > 0) {
      generateTable(sb, "FAILED TESTS BUT WITHIN SUCCESS PERCENTAGE",
          percentageTests, HTMLConstants.LIGHT_GREEN);
    }
    if (passedTests.size() > 0) {
      generateTable(sb, "PASSED TESTS", passedTests, HTMLConstants.GREEN);
    }
    if (skippedTests.size() > 0) {
      generateTable(sb, "SKIPPED TESTS", skippedTests, HTMLConstants.YELLOW);
    }
    
    sb.append("</body>\n</html>");
    
    Utils.writeFile(htmlOutputFile, sb.toString());
	}

	private static void ppp(String s) {
    System.out.println("[TestHTMLReporter] " + s);
  }
	
}
