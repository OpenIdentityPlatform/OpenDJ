package org.testng;


import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.DirectoryScanner;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.taskdefs.Java;
import org.apache.tools.ant.types.FileSet;
import org.apache.tools.ant.types.Path;
import org.apache.tools.ant.types.Reference;

/**
 * TestNG Ant task. It supports the following:
 * <P/>
 * Attributes:
 * <ul>
 *  <li><tt>enableAssert</tt> (boolean): enable JDK 1.4 assertion (default: <b>true</b>)</li>
 *  
 *  <li><tt>dumpCommand</tt> (boolean): dumps the command line used to start TestNG (default: <b>false</b>)</li>
 *  
 *  <li>
 *    <tt>suiteRunnerClass</tt> (String): fully qualified class name of another TestNG starter 
 *    (default: <b>org.testng.TestNG</b>)
 *  </li>
 *  
 *  <li>
 *    <tt>classfilesetref</tt> (Reference to FileSet): fileset of .java or .class to be run (console suite)
 *  </li>
 *  
 *  <li>
 *    <tt>classpathref</tt> (Reference to Path): classpath to be used by TestNG
 *  </li>
 *  
 *  <li><tt>outputdir</tt> (String): output directory for generating TestNG reports</li>
 *  
 *  <li><tt>sourcedir</tt> (Path): path-like for .java (used only for JDK 1.4 tests)</li>
 *  
 *  <li><tt>sourcedirref</tt> (Reference to Path): reference to a path for .java (used only for JDK 1.4 tests)</li>
 * </ul>
 *
 * @author <a href='mailto:the_mindstorm@evolva.ro'>Alexandru Popescu</a>
 * 
 * @deprecated Use TestNGAntTask
 */
public class TestNGAntTask2 extends Java {
  protected List    m_xmlFilesets = new ArrayList();
  protected List    m_clsFilesets = new ArrayList();

  protected Path    m_sourceDirPath;
  protected String  m_mainClass = TestNG.class.getName();
  protected String  m_outdir;
  protected String  m_testjar;
  protected Path    m_classpath;

  protected boolean m_enableAssert = true;

  // Fields for logging
  protected boolean m_dumpCommand = false;

  public void addXmlfileset(FileSet fs) {
    m_xmlFilesets.add(fs);
  }

  public void setXmlfilesetRef(Reference ref) {
    addXmlfileset(createFileSet(ref));
  }

  public void addClassfileset(FileSet fs) {
    m_clsFilesets.add(fs);
  }

  public void setClassfilesetRef(Reference ref) {
    addClassfileset(createFileSet(ref));
  }

  /**
   * Sets the flag to log the command line.
   */
  public void setDumpCommand(boolean verbose) {
    m_dumpCommand = verbose;
  }

  /**
   * Sets the suite runner class to invoke
   * @param s the name of the suite runner class
   */
  public void setSuiteRunnerClass(String s) {
    m_mainClass = s;
  }

  /**
   * Sets the test output directory
   * @param s the name of directory
   */
  public void setOutputDir(String s) {
    m_outdir = s;
  }

  /**
   * Sets the test jar
   * @param s the name of test jar
   */
  public void setTestJar(String s) {
    m_testjar = s;
  }


  @Override
  public Path createClasspath() {
    Path cp = super.createClasspath();

    if(m_classpath == null) {
      m_classpath = cp;
    }
    else {
      m_classpath.append(cp);
    }

    return cp;
  }

  /**
   * Set the classpath to be used when running the Java class
   *
   * @param s an Ant Path object containing the classpath.
   */
  @Override
  public void setClasspath(Path s) {
    if(m_classpath == null) {
      m_classpath = createClasspath();
    }

    m_classpath.append(s);
    super.setClasspath(s);
  }

  /**
   * Classpath to use, by reference.
   *
   * @param r a reference to an existing classpath
   */
  @Override
  public void setClasspathRef(Reference r) {
    if(m_classpath == null) {
      m_classpath = createClasspath();
    }

    m_classpath.setRefid(r);
    super.setClasspathRef(r);
  }

  public void setEnableAssert(boolean flag) {
    m_enableAssert = flag;
  }

  /**
   * Sets the Path like for source directories.
   * @param srcDir path for source directories
   */
  public void setSourcedir(Path srcDir) {
    if(m_sourceDirPath == null) {
      m_sourceDirPath = srcDir;
    }
    else {
      m_sourceDirPath.append(srcDir);
    }
  }

  /**
   * Creates a nested src Path like.
   *
   * @return a new Path
   */
  public Path createSourceDir() {
    if(m_sourceDirPath == null) {
      m_sourceDirPath = new Path(getProject());
    }

    return m_sourceDirPath.createPath();
  }

  /**
   * Sets a reference to a Path-like structure for source directories.
   *
   * @param r reference to a Path representing the source directories
   */
  public void setSourceDirRef(Reference r) {
    createSourceDir().setRefid(r);
  }

  private FileSet createFileSet(Reference ref) {
    FileSet fs = new FileSet();
    fs.setRefid(ref);
    fs.setProject(getProject());

    return fs;
  }

  @Override
  public void execute() throws BuildException {
    if(m_enableAssert) {
      createJvmarg().setValue("-ea");
    }

    setClassname(m_mainClass);

    if((null != m_outdir) && !"".equals(m_outdir)) {
      createArg().setValue(TestNGCommandLineArgs.OUTDIR_COMMAND_OPT);
      createArg().setValue(m_outdir);
    }

    if((null != m_testjar) && !"".equals(m_testjar)) {
      createArg().setValue(TestNGCommandLineArgs.TESTJAR_COMMAND_OPT);
      createArg().setValue(m_testjar);
    }

    if(null != m_sourceDirPath) {
      String srcPath = createPathString(m_sourceDirPath, ";");
      createArg().setValue(TestNGCommandLineArgs.SRC_COMMAND_OPT);
      createArg().setValue(srcPath);
    }

    if(m_clsFilesets.size() > 0) {
      createArg().setValue(TestNGCommandLineArgs.TESTCLASS_COMMAND_OPT);
      createArg().setValue(filesetToString(m_clsFilesets, " "));
    }

    if(m_xmlFilesets.size() > 0) {
      createArg().setValue(filesetToString(m_xmlFilesets, " "));
    }

    if(m_dumpCommand) {
      log(dumpCommand(), Project.MSG_INFO);
    }
    
    super.execute();
  }

  private String filesetToString(List filesets, String sep) throws BuildException {
    final StringBuffer buf = new StringBuffer();

    for(Iterator iterator = filesets.iterator(); iterator.hasNext();) {
      FileSet          fileset = (FileSet) iterator.next();
      DirectoryScanner ds = fileset.getDirectoryScanner(getProject());
      for(int i = 0; i < ds.getIncludedFiles().length; i++) {
        String file = ds.getIncludedFiles()[i];
        buf.append(ds.getBasedir() + File.separator + file).append(sep);
      }
    }

    return buf.toString();
  }

  /**
   * Creates a string representation of the path.
   */
  private String createPathString(Path path, String sep) {
    if(path == null) {
      return null;
    }

    final StringBuffer buf = new StringBuffer();

    for(int i = 0; i < path.list().length; i++) {
      File file = getProject().resolveFile(path.list()[i]);

      if(!file.exists()) {
        log("Classpath entry not found: " + file, Project.MSG_WARN);
      }

      buf.append(file.getAbsolutePath()).append(sep);
    }

    if(path.list().length > 0) { // cut the last ;
      buf.deleteCharAt(buf.length() - 1);
    }

    return buf.toString();
  }
  
  /**
   * Creates a string representation of the command to be run.
   */
  private String dumpCommand() {
    final StringBuffer dumpBuf = new StringBuffer("java ");

    if(m_enableAssert) {
      dumpBuf.append("-ea ");
    }

    if(null != m_classpath) {
      dumpBuf.append("-cp ")
          .append(createPathString(m_classpath, File.pathSeparator))
          .append(" ")
          ;
    }

    dumpBuf.append(m_mainClass).append(" ");

    if((null != m_outdir) && !"".equals(m_outdir)) {
      dumpBuf.append(TestNGCommandLineArgs.OUTDIR_COMMAND_OPT)
          .append(" ")
          .append(m_outdir)
          .append(" ")
          ;
    }

    if((null != m_testjar) && !"".equals(m_testjar)) {
      dumpBuf.append(TestNGCommandLineArgs.TESTJAR_COMMAND_OPT)
          .append(" ")
          .append(m_testjar)
          .append(" ")
          ;
    }

    if(null != m_sourceDirPath) {
      dumpBuf.append(TestNGCommandLineArgs.SRC_COMMAND_OPT)
          .append(" ")
          .append(createPathString(m_sourceDirPath, ";"))
          .append(" ")
          ;
    }

    if(m_clsFilesets.size() > 0) {
      dumpBuf.append(TestNGCommandLineArgs.TESTCLASS_COMMAND_OPT)
          .append(" ")
          .append(filesetToString(m_clsFilesets, " "))
          .append(" ")
          ;
    }

    if(m_xmlFilesets.size() > 0) {
      dumpBuf.append(filesetToString(m_xmlFilesets, " "));
    }

    return dumpBuf.toString();
  }
}
