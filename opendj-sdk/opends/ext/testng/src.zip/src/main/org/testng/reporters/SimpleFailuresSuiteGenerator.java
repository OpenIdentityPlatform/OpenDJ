package org.testng.reporters;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestClass;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;
import org.testng.TestRunner;
import org.testng.internal.Utils;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

/**
 * A very custom ISuiteListener that will generate the testng-failed.xml definition.
 * <P/>
 * In case of a failure we need the following info:
 * - suite-verbose, parallel, thread-count, annotations
 * - all parameters declared in the suite
 * - all parameters declared in the enclosing test definition of the failed one
 * 
 * @author <a href='mailto:the_mindstorm@evolva.ro'>Alexandru Popescu</a>
 * 
 * @deprecated Now using FailedReporter
 */
public class SimpleFailuresSuiteGenerator 
  implements ITestListener, ISuiteListener 
{
  public static final String TESTNG_FAILURES_XML = FailedReporter.TESTNG_FAILED_XML;
  
  private XmlSuite m_xmlSuite;
  private boolean m_hasFailures;
  private String m_currentTestName;

  /** Map<testname, XmlTest>. */
  private Map<String, XmlTest> m_testNames= new HashMap<String, XmlTest>();
  /** Map<testname, XmlTest> only for tests containing FAILURES, SKIPS OR SPF. */
  private Map<String, XmlTest> m_failedTestNames= new HashMap<String, XmlTest>();
  /** Map<testname, XmlTestMethods> containing the list of failed methods occurring inside of an XmlTest. */
  private Map<String, XmlTestMethods> m_testNameMethods= new HashMap<String, XmlTestMethods>();
  /** Map<testname, outputdir>. */
  private Map<String, String> m_outputs= new HashMap<String, String>();
  
  /**
   * Complex structure that keeps for every XmlTest the Map of classes and their
   * before/afterSuite methods. Used to create some additional tests in case of
   * failures.
   */
  private Map<String, Map<String, Map<Method, ITestNGMethod>>> m_suiteConfMethods
      = new HashMap<String, Map<String, Map<Method, ITestNGMethod>>>();

  public SimpleFailuresSuiteGenerator(XmlSuite xmlSuite) {
    m_xmlSuite= xmlSuite;

    for (XmlTest xt: xmlSuite.getTests()) {
      m_testNames.put(xt.getName(), xt);
    }
  }
  
  public void registerRunner(TestRunner tr) {
    XmlTest xmlTest= tr.getTest();
    String testName= xmlTest.getName();
    
    if (!m_testNames.containsKey(testName)) {
      System.err.println("[ERROR]: the test " + testName + " wasn't registered!");
      m_testNames.put(testName, xmlTest);
    }
    
    m_outputs.put(testName, tr.getOutputDirectory());
    m_testNameMethods.put(testName, new XmlTestMethods(xmlTest, tr.getIClass()));
    
    Map<String, Map<Method, ITestNGMethod>> classMethods= new HashMap<String, Map<Method, ITestNGMethod>>();
    
    for(ITestNGMethod itm: tr.getBeforeSuiteMethods()) {
      String fqn= itm.getRealClass().getName();
      Map<Method, ITestNGMethod> methods= classMethods.get(fqn);
      
      if (null == methods) {
        methods= new HashMap<Method, ITestNGMethod>();
        classMethods.put(fqn, methods);
      }
      
      methods.put(itm.getMethod(), itm);
    }
    
    for(ITestNGMethod itm: tr.getAfterSuiteMethods()) {
      String fqn= itm.getRealClass().getName();
      Map<Method, ITestNGMethod> methods= classMethods.get(fqn);
      
      if (null == methods) {
        methods= new HashMap<Method, ITestNGMethod>();
        classMethods.put(fqn, methods);
      }
      
      methods.put(itm.getMethod(), itm);
    }
    
    m_suiteConfMethods.put(testName, classMethods);
  }
  
  public void onStart(ISuite suite) {
    ;
  }

  public void onFinish(ISuite suite) {
    if (!m_hasFailures) {
      return; // nothing to generate
    }
    
    Map<String, Set<String>> testperOut= regroupByOutput(m_outputs);
    
    for(String outdir: testperOut.keySet()) {
      Set<String> testnames= testperOut.get(outdir);
      
      XmlSuite newsuite= generateSuite(testnames);
      if (newsuite.getTests().size() > 0) { 
        Utils.writeFile(outdir, TESTNG_FAILURES_XML, newsuite.toXml());
      }
    }
  }

  public void onTestStart(ITestResult result) {
    ;
  }
  
  public void onTestSuccess(ITestResult result) {
    if(result.getMethod().isTest()) {
      if(null != m_currentTestName) {
        XmlTestMethods xmlTestMethods= m_testNameMethods.get(m_currentTestName);
        if (xmlTestMethods != null ) {
          xmlTestMethods.addSuccessTestMethod(result.getMethod());
        }
      }
      else {
        System.err.println("ITestResult without a name");
      }
    }
  }
  
  private void ppp(String s) {
    System.out.println(("[SimpleFailuresSuiteGenerator] " + s));
  }
  
  public void onTestFailure(ITestResult result) {
    registerFailedTest(m_currentTestName, result);
  }

  public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
    registerFailedTest(m_currentTestName, result);
  }

  public void onTestSkipped(ITestResult result) {
    registerFailedTest(m_currentTestName, result);
  }

  public void onStart(ITestContext context) {
    m_currentTestName= context.getName();
  }

  public void onFinish(ITestContext context) {
    m_currentTestName= null;
  }

  private void registerFailedTest(final String testName, final ITestResult result) {
    m_hasFailures= true;
    
    ITestNGMethod mth= result.getMethod();

    if (mth.isTest()) {
      XmlTestMethods xmlTestMethods= m_testNameMethods.get(testName);

      if (xmlTestMethods != null) {
        xmlTestMethods.addFailedTestMethod(mth);
        m_failedTestNames.put(testName, m_testNames.get(testName));
      }
    }
  }
  
  /**
   * Generates an XmlSuite with a subset of XmlTests and possibly additional
   * XmlTests containing beforeSuite and afterSuite.
   * 
   * @param testnames names of original XmlTests that will be scanned and included
   * 
   * @return an XmlSuite containing the failures and all the available context
   */
  private XmlSuite generateSuite(Set<String> testnames) {
    XmlSuite failedSuite= cloneSuiteDef(m_xmlSuite); 

    for(String name: testnames) {
      if(!m_failedTestNames.containsKey(name)) {
        continue;
      }
      
      XmlTest xmlTest= m_failedTestNames.get(name);
      XmlTest newtest= cloneTestDef(failedSuite, xmlTest);
      XmlTestMethods xmlTestMeths= m_testNameMethods.get(name);
      
      for(XmlClass xmlClass: xmlTest.getXmlClasses()) {
        Class testClass= xmlClass.getSupportClass();

        Map<String, String> dependedOnMethods= new HashMap<String, String>();
        Map<String, ITestNGMethod> failedMeths= xmlTestMeths.getFailedMethods(testClass);

        for(String methodName: failedMeths.keySet()) {
          ITestNGMethod failed= failedMeths.get(methodName);
          for(String mName: failed.getMethodsDependedUpon()) {
            dependedOnMethods.put(mName, mName);
          }
        }
        
        Map<String, ITestNGMethod> successMeths= xmlTestMeths.getSuccessMethods(testClass);
        
        XmlClass newclass= clone(xmlClass);
        
        if(successMeths.size() > 0) {
          // remove success methods from <include>; check if there is no failed dependency on them!
          List<String> includes= newclass.getIncludedMethods();
          List<String> newincludes= new ArrayList<String>();
          for(String methodName: includes) {
            if(!successMeths.containsKey(methodName)
                || dependedOnMethods.containsKey(methodName)) {
              newincludes.add(methodName);
            }
          }
          newclass.setIncludedMethods(newincludes);
          
          List<String> excludes= newclass.getExcludedMethods();
          for(String methodName: successMeths.keySet()) {
            if(!excludes.contains(methodName) && !dependedOnMethods.containsKey(methodName)) {
              excludes.add(methodName);
            }
          }
        }
       
        newtest.getXmlClasses().add(newclass);
      }
    }
    
    if (failedSuite.getTests().size() > 0) {
      // add beforeSuite/afterSuite special test
      for(String testname: m_suiteConfMethods.keySet()) {
        if (!testnames.contains(testname)) {
          XmlTest xmlTest= m_testNames.get(testname);
          XmlTest newxmltest= cloneTestDef(failedSuite, xmlTest);
          newxmltest.setName(xmlTest.getName() + "- suite methods only");
          
          Map<String, Map<Method, ITestNGMethod>> classMeths= m_suiteConfMethods.get(testname);
          
          for(XmlClass suiteDefClass: xmlTest.getXmlClasses()) {
            Map<Method, ITestNGMethod> meths= classMeths.get(suiteDefClass.getName());
            
            if(null != meths) {
              XmlClass newclass= clone(suiteDefClass);
              
              for(Method m: meths.keySet()) {
                newclass.getIncludedMethods().add(m.getName());
              }
              
              newxmltest.getXmlClasses().add(newclass);
            }
          }
        }
      }
    }
    
    return failedSuite;
  }
  
  private XmlSuite cloneSuiteDef(XmlSuite srcSuite) {
    XmlSuite suite= new XmlSuite();
    suite.setName("Failed Tests suite");
    suite.setAnnotations(srcSuite.getAnnotations());
    suite.setParallel(srcSuite.isParallel());
    suite.setThreadCount(srcSuite.getThreadCount());
    suite.setParameters(srcSuite.getAllParameters());
    suite.setVerbose(srcSuite.getVerbose());
    suite.setXmlPackages(srcSuite.getXmlPackages());
    suite.setBeanShellExpression(srcSuite.getExpression());
    suite.setMethodSelectors(srcSuite.getMethodSelectors());

    return suite;
  }
  
  /**
   * Clone the <TT>source</TT> <CODE>XmlTest</CODE> by including: 
   * - test attributes
   * - groups definitions
   * - parameters
   * 
   * The &lt;classes&gt; subelement is ignored for the moment.
   * 
   * @param suite
   * @param source
   * @return
   */
  private XmlTest cloneTestDef(XmlSuite suite, XmlTest source) {
    XmlTest result= new XmlTest(suite);
    
    result.setName(source.getName());
    result.setAnnotations(source.getAnnotations());
    result.setIncludedGroups(source.getIncludedGroups());
    result.setExcludedGroups(source.getExcludedGroups());
    result.setJUnit(source.isJUnit());
    result.setParallel(source.isParallel());
    result.setVerbose(source.getVerbose());
    result.setParameters(source.getParameters());
    result.setXmlPackages(source.getXmlPackages());
    
    Map<String, List<String>> metagroups= source.getMetaGroups();
    for (String groupName: metagroups.keySet()) {
      result.addMetaGroup(groupName, metagroups.get(groupName));
    }
    
    return result;
  }
  
  /**
   * Clone an XmlClass by copying all its components.
   * 
   * @param source
   * @return
   */
  private XmlClass clone(XmlClass source) {
    XmlClass newclass= new XmlClass(source.getName());
    newclass.setExcludedMethods(source.getExcludedMethods());
    newclass.setIncludedMethods(source.getIncludedMethods());
    
    return newclass;
  }

  
  private Map<String, Set<String>> regroupByOutput(Map<String, String> outputs) {
    Map<String, Set<String>> result= new HashMap<String, Set<String>>();
    
    for(String testname: outputs.keySet()) {
      String outdir= outputs.get(testname);
      
      Set<String> names= result.get(outdir);
      
      if (null == names) {
        names= new HashSet<String>();
        result.put(outdir, names);
      }
      
      names.add(testname);
    }
    
    return result;
  }
  
  private static class XmlTestMethods implements Serializable {
    private XmlTest m_xmlTest;
    private Map<String, ITestClass> m_testClasses= new HashMap<String, ITestClass>();
    
    private Map<String, Map<Method, ITestNGMethod>> m_failedMethsOnClass= new HashMap<String, Map<Method, ITestNGMethod>>();
    private Map<String, Map<Method, ITestNGMethod>> m_successMethsOnClass= new HashMap<String, Map<Method, ITestNGMethod>>();
    
    public XmlTestMethods(XmlTest xmlTest, Collection<ITestClass> testClasses) {
      m_xmlTest= xmlTest;
      
      for(ITestClass itc: testClasses) {
        m_testClasses.put(itc.getRealClass().getName(), itc);
      }
    }
    
    public void addFailedTestMethod(ITestNGMethod itm) {
      final String fqn= itm.getRealClass().getName();
      Map<Method, ITestNGMethod> methods= m_failedMethsOnClass.get(fqn);
      
      if (null==methods) {
        methods= new HashMap<Method, ITestNGMethod>();
        m_failedMethsOnClass.put(fqn, methods);
      }
      
      methods.put(itm.getMethod(), itm);
    }
    
    public void addSuccessTestMethod(ITestNGMethod itm) {
      final String fqn= itm.getRealClass().getName();
      Map<Method, ITestNGMethod> methods= m_successMethsOnClass.get(fqn);
      
      if(null == methods) {
        methods= new HashMap<Method, ITestNGMethod>();
        m_successMethsOnClass.put(fqn, methods);
      }
      
      methods.put(itm.getMethod(), itm);
    }
    
    protected Map<String, ITestNGMethod> getSuccessMethods(Class clazz) {
      Map<String, ITestNGMethod> result= new HashMap<String, ITestNGMethod>();
      Map<Method, ITestNGMethod> passedMeths= m_successMethsOnClass.get(clazz.getName());
      
      if(null != passedMeths) {
        for(Method m: passedMeths.keySet()) {
          result.put(m.getName(), passedMeths.get(m));
        }
      }
      
      if(null != clazz.getSuperclass() && clazz.getSuperclass() != Object.class) {
        result.putAll(getSuccessMethods(clazz.getSuperclass()));
      }
      
      return result;
    }
    
    /**
     * Get a Map of failed methods for the specified class.
     */
    protected Map<String, ITestNGMethod> getFailedMethods(Class clazz) {
      Map<String, ITestNGMethod> result= new HashMap<String, ITestNGMethod>();
      Map<Method, ITestNGMethod> failedMethods= m_failedMethsOnClass.get(clazz.getName());

      if(null != failedMethods) {
        for(Method m: failedMethods.keySet()) {
          result.put(m.getName(), failedMethods.get(m));
        }
      }
      
      if(null != clazz.getSuperclass() && clazz.getSuperclass() != Object.class) {
        result.putAll(getFailedMethods(clazz.getSuperclass()));
      }
      
      return result;
    }
  }

}
