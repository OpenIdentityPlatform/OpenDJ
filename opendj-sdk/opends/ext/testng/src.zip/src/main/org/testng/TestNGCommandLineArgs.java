package org.testng;


import org.testng.internal.ClassHelper;
import org.testng.internal.Utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * TestNG/RemoteTestNG command line arguments parser.
 * 
 * @author Cedric Beust
 * @author <a href='mailto:the_mindstorm@evolva.ro'>Alexandru Popescu</a>
 */
public class TestNGCommandLineArgs {
  public static final String OUTDIR_COMMAND_OPT = "-d";
  public static final String TESTCLASS_COMMAND_OPT = "-testclass";
  public static final String TESTJAR_COMMAND_OPT = "-testjar";
  public static final String SRC_COMMAND_OPT = "-sourcedir";
  // These next two are used by the Eclipse plug-in
  public static final String PORT_COMMAND_OPT = "-port";
  public static final String HOST_COMMAND_OPT = "-host";
  public static final String LOG = "-log";
  public static final String TARGET_COMMAND_OPT = "-target";
  public static final String GROUPS_COMMAND_OPT = "-groups";
  public static final String EXCLUDED_GROUPS_COMMAND_OPT = "-excludegroups";
  public static final String TESTRUNNER_FACTORY_COMMAND_OPT = "-testrunfactory";
  public static final String LISTENER_COMMAND_OPT = "-listener";
  public static final String SUITE_DEF_OPT = "testng.suite.definitions";
  public static final String JUNIT_DEF_OPT = "-junit";
  public static final String SLAVE_OPT = "-slave";
  public static final String HOSTFILE_OPT = "-hostfile";

  public static Map parseCommandLine(final String[] argv) {
    Map arguments = new HashMap();

    for(int i = 0; i < argv.length; i++) {
      if(OUTDIR_COMMAND_OPT.equalsIgnoreCase(argv[i])) {
        if((i + 1) < argv.length) {
          arguments.put(OUTDIR_COMMAND_OPT, argv[i + 1].trim());
        }
        else {
          System.err.println("WARNING: missing output directory after -d.  ignored");
        }
        i++;
      }
      else if(GROUPS_COMMAND_OPT.equalsIgnoreCase(argv[i]) ||
          EXCLUDED_GROUPS_COMMAND_OPT. equalsIgnoreCase(argv[i]))
      {
        if((i + 1) < argv.length) {
          String option = null;
          if(argv[i + 1].startsWith("\"")) {
            if(argv[i + 1].endsWith("\"")) {
              option = argv[i + 1].substring(1, argv[i + 1].length() - 1);
            }
            else {
              System.err.println("WARNING: groups option is not well quoted:" + argv[i + 1]);
              option = argv[i + 1].substring(1);
            }
          }
          else {
            option = argv[i + 1];
          }

          String opt = GROUPS_COMMAND_OPT.equalsIgnoreCase(argv[i]) ?
              GROUPS_COMMAND_OPT : EXCLUDED_GROUPS_COMMAND_OPT;
          arguments.put(opt, option);
        }
        else {
          System.err.println("WARNING: missing groups paramter after -groups. ignored");
        }
        i++;
      }
      else if(LOG.equalsIgnoreCase(argv[i])) {
        if((i + 1) < argv.length) {
          arguments.put(LOG, Integer.parseInt(argv[i + 1].trim()));
        }
        else {
          System.err.println("WARNING: missing log level after -log.  ignored");
        }
        i++;
      }
      else if(JUNIT_DEF_OPT.equalsIgnoreCase(argv[i])) {
        arguments.put(JUNIT_DEF_OPT, Boolean.TRUE);
      }
      else if(TARGET_COMMAND_OPT.equalsIgnoreCase(argv[i])) {
        if((i + 1) < argv.length) {
          if("1.4".equals(argv[i + 1]) || "1.5".equals(argv[i + 1])) {
            arguments.put(TARGET_COMMAND_OPT, argv[i + 1]);
          }
          else {
            System.err.println("WARNING: missing/invalid target argument. Must be 1.4 or 1.5. Ignoring");
          }
          i++;
        }
      }
      else if(TESTRUNNER_FACTORY_COMMAND_OPT.equalsIgnoreCase(argv[i])) {
        if((i + 1) < argv.length) {
          arguments.put(TESTRUNNER_FACTORY_COMMAND_OPT, fileToClass(argv[++i]));
        }
        else {
          System.err.println("WARNING: missing ITestRunnerFactory class or file argument after "
              + TESTRUNNER_FACTORY_COMMAND_OPT);
        }
      }
      else if(LISTENER_COMMAND_OPT.equalsIgnoreCase(argv[i])) {
        if((i + 1) < argv.length) {
          String[] strs= Utils.split(argv[++i], ";");
          List<Class> classes= new ArrayList<Class>();

          for(String cls: strs) {
            classes.add(fileToClass(cls));
          }

          arguments.put(LISTENER_COMMAND_OPT, classes);
        }
        else {
          System.err.println("WARNING: missing ITestListener class/file list argument after "
              + LISTENER_COMMAND_OPT);
        }
      }
      else if(TESTCLASS_COMMAND_OPT.equalsIgnoreCase(argv[i])) {
        if((i + 1) < argv.length) {
          while((i + 1) < argv.length) {
            String nextArg = argv[i + 1].trim();
            if(!nextArg.toLowerCase().endsWith(".xml") && !nextArg.startsWith("-")) {

              // Assume it's a class name
              List<Class> l = (List<Class>) arguments.get(TESTCLASS_COMMAND_OPT);
              if(null == l) {
                l = new ArrayList<Class>();
                arguments.put(TESTCLASS_COMMAND_OPT, l);
              }
              Class cls = fileToClass(nextArg);
              if(null != cls) {
                l.add(cls);
              }

              i++;
            } // if
            else {
              break;
            }
          }
        }
        else {
          TestNG.exitWithError("-testclass must be followed by a classname");
        }
      }
      else if(TESTJAR_COMMAND_OPT.equalsIgnoreCase(argv[i])) {
        if((i + 1) < argv.length) {
          arguments.put(TESTJAR_COMMAND_OPT, argv[i + 1].trim());
        }
        else {
          TestNG.exitWithError("-testjar must be followed by a valid jar");
        }
        i++;
      }
      else if(SRC_COMMAND_OPT.equalsIgnoreCase(argv[i])) {
        if((i + 1) < argv.length) {
          arguments.put(SRC_COMMAND_OPT, argv[i + 1].trim());
        }
        else {
          TestNG.exitWithError(SRC_COMMAND_OPT + " must be followed by the a directory path");
        }
        i++;
      }
      else if(HOST_COMMAND_OPT.equals(argv[i])) {
        String hostAddress = "127.0.0.1";
        if((i + 1) < argv.length) {
          hostAddress = argv[i + 1].trim();
          i++;
        }
        else {
          System.out.println("WARNING: "
              + HOST_COMMAND_OPT
              + " option should be followed by the host address. "
              + "Using default localhost.");
        }

        arguments.put(HOST_COMMAND_OPT, hostAddress);

      }
      else if(PORT_COMMAND_OPT.equals(argv[i])) {
        String portNumber = null;
        if((i + 1) < argv.length) {
          portNumber = argv[i + 1].trim();
        }
        else {
          TestNG.exitWithError(PORT_COMMAND_OPT + " option should be followed by a valid port number.");
        }

        arguments.put(PORT_COMMAND_OPT, portNumber);
        i++;
      }
      else if(SLAVE_OPT.equals(argv[i])) {
        String clientPortNumber = null;
        if((i + 1) < argv.length) {
          clientPortNumber = argv[i + 1].trim();
        }
        else {
          TestNG.exitWithError(SLAVE_OPT + " option should be followed by a valid port number.");
        }

        arguments.put(SLAVE_OPT, clientPortNumber);
        i++;
      }
      else if(HOSTFILE_OPT.equals(argv[i])) {
        String hostFile= null;
        if((i + 1) < argv.length) {
          hostFile = argv[i + 1].trim();
        }
        else {
          TestNG.exitWithError(HOSTFILE_OPT + " option should be followed by the name of a file.");
        }

        arguments.put(HOSTFILE_OPT, hostFile);
        i++;
      }
      else if (argv[i].startsWith("-")) {
        TestNG.exitWithError("Unknown option: " + argv[i]);
      }
      else {
        List<String> suiteDefs = new ArrayList<String>();

        for(int k = i; k < argv.length; k++) {
          String file = argv[k].trim();
          if(file.toLowerCase().endsWith(".xml") || file.endsWith(".XML")) {
            suiteDefs.add(file);
            i++;
          }
        }

        arguments.put(SUITE_DEF_OPT, suiteDefs);
      }
    }

    return arguments;
  }

  private static int m_lastGoodRootIndex = -1;

  private static Class fileToClass(String file) {
    Class result = null;
    int classIndex = file.indexOf(".class");
    if (-1 == classIndex) {
      classIndex = file.indexOf(".java");
      if (-1 == classIndex) {
        // Doesn't end in .java or .class, assume it's a class name
        result = ClassHelper.forName(file);

        if(null == result) {
          throw new TestNGException("Couldn't convert to class: " + file);
        }

        return result;
      }
    }

    String shortFileName = file.substring(0, classIndex);
    shortFileName = shortFileName.replace('/', '.').replace('\\', '.');
    String[] segments = shortFileName.split("\\.", -1);

    //
    // Check if the last good root index works for this one
    //
    if (-1 != m_lastGoodRootIndex) {
      String className = segments[m_lastGoodRootIndex];
      for (int i = m_lastGoodRootIndex + 1; i < segments.length; i++) {
        className += "." + segments[i];
      }

      result = ClassHelper.forName(className);

      if(null != result) {
        return result;
      }
    }

    //
    // We haven't found a good root yet, start by resolving
    // the class from the end and work our way up.  For example,
    // if we start with c:/java/testng/classes/com/foo/A
    // we'll start by resolving "A", then "foo.A", then "com.foo.A" until
    // something resolves.  When it does, we remember the path we are
    // at as "lastGoodRoodIndex".
    //
    String className = null;
    for(int i = segments.length - 1; i >= 0; i--) {
      if(null == className) {
        className = segments[i];
      }
      else {
        className = segments[i] + "." + className;
      }

      result = ClassHelper.forName(className);

      if(null != result) {
        m_lastGoodRootIndex = i;
        break;
      }
    }

    if(null == result) {
      throw new TestNGException("Couldn't convert to class: " + file);
    }

    return result;
  }

  private static void ppp(Object msg) {
    System.out.println("[CMD]: " + msg);
  }
}
