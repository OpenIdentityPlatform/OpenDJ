package org.testng.internal;

import java.lang.reflect.Method;
import java.util.Comparator;

import org.testng.ITestNGMethod;
import org.testng.internal.annotations.AnnotationHelper;
import org.testng.internal.annotations.IAnnotationFinder;
import org.testng.internal.annotations.ITest;


/**
 * This class represents a test method.
 *
 * @author Cedric Beust, May 3, 2004
 * @author <a href='mailto:the_mindstorm@evolva.ro'>Alexandru Popescu</a>
 */
public class TestNGMethod 
  extends BaseTestMethod 
  implements ITestNGMethod, Comparable
{  
  private int m_invocationCount = 1;
  private int m_successPercentage = 100;
  private long m_timeOut = 0;

  public TestNGMethod(Method method, IAnnotationFinder finder) {
    super(method, finder);
    
    init();
  }

  @Override
  public long getTimeOut() {
    return m_timeOut;
  }
  
  @Override
  public int getInvocationCount() {
    return m_invocationCount;
  }
  
  @Override
  public int getSuccessPercentage() {
    return m_successPercentage;
  }
    
  @Override
  public boolean isTest() {
    return true;
  }

  private void init() {
    {
      ITest testAnnotation = AnnotationHelper.findTest(getAnnotationFinder(), m_method);

      if (null != testAnnotation) {
        m_timeOut = testAnnotation.getTimeOut();
      }

      if (null != testAnnotation) {
        Integer ic = testAnnotation.getInvocationCount();
        if (null != ic) {
          m_invocationCount = ic.intValue();
        }
        Integer sp = testAnnotation.getSuccessPercentage();
        if (null != sp) {
          m_successPercentage = sp.intValue();
        }
        Integer tps = testAnnotation.getThreadPoolSize();
        if (null != tps) {
          setThreadPoolSize(tps.intValue());
        }
      }

      // Groups
      {
        initGroups(ITest.class);
      }

      // Other annotations
      if (null != testAnnotation) {
        setAlwaysRun(testAnnotation.getAlwaysRun());
        setDescription(testAnnotation.getDescription());
      }
    }
  }
  
  public static final Comparator<ITestNGMethod> SORT_BY_CLASS =
    new Comparator<ITestNGMethod>(){
    
      public int compare(ITestNGMethod o1, ITestNGMethod o2) {
        String c1 = o1.getTestClass().getName();
        String c2 = o2.getTestClass().getName();
        return c1.compareTo(c2);
      }
    };

}
